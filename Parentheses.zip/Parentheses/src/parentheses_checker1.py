import stack

def parentheses_checker1(file):
    """
    Returns the phrase 'Well parenthesed' if each open parenthesis has
    the matching close one.
    In the opposite case, returns the phrase 'Bad parenthesed'.

    :param file: file ( .txt, .py, etc.)
    :return: 'Well parenthesed'/'Bad parenthesed'
    :rtype: str
    :UC: file is an external file
    :example:

    >>> parentheses_checker1('stack.py')
    'Well parenthesed'
    >>> parentheses_checker1('bad_stack1.py')
    'Bad parenthesed'
    >>> parentheses_checker1('bad_stack3.py')
    'Bad parenthesed'
    
    """
    f=open(file, mode="r", encoding="utf-8")
    strInput = f.read()
    if strInput:
        brackets = [ ('(',')'), ('[',']'), ('{','}')]
        kStart = 0
        kEnd = 1

        stck=stack.Stack()

        for char in strInput:
            for bracketPair in brackets:
                if char == bracketPair[kStart]:
                    stck.push(char)
                elif char == bracketPair[kEnd] and not stck.is_empty() and stck.pop() != bracketPair[kStart]:
                    return 'Bad parenthesed'

        if stck.is_empty():
            return 'Well parenthesed'

    return 'Bad parenthesed'

if __name__ == "__main__":
   import doctest, sys
   doctest.testmod()

   n = str(sys.argv[1])
   print(parentheses_checker1(n))
