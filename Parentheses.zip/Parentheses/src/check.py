def check(b):
    return b+10

if __name__ == "__main__":
   import doctest, sys
   doctest.testmod()

   n = int(sys.argv[1])
   print(check(n))
