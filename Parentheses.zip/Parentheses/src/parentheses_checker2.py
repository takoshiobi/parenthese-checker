import stack

class ParenthesisError(Exception):
    pass
    # there's no need to use this class as exception is this case
    # because there's no racing errors
    # but in case of errors usage all 'print's in this file
    # should be replaced with 'raise'
    def __init__(self, parenthesis, error):
        what_is_wrong = '%s at line %s, char number %s, the problem is >>> %s'
        parenthesis.line = parenthesis.line.replace('\n', '\\n')
        self.what_is_wrong = what_is_wrong % (error ,parenthesis.i_line-1, parenthesis.i_char-1, parenthesis.line)
 
    def __str__(self):
        return self.what_is_wrong
 
 
class Parenthesis:
    def __init__(self, i_line, line, i_char):
        self.i_line = i_line
        self.line = line
        self.i_char = i_char
 
 
def parentheses_checker2(filename):
    """
    Returns the line, char number and phase containing unbalanced
    parentheses is there's parenthesis problem.
    In the opposite case, returns nothing.

    :param file: file ( .txt, .py, etc.)
    :return: None or line, char number and phase
    :rtype: str or None
    :UC: file is an external file
    :example:

    >>> parentheses_checker2('stack.py')
    >>> parentheses_checker2('bad_stack2.py')
    Wrong open parenthesis at line 99, char number 16, the problem is >>>     def is_empty(self:
    >>> parentheses_checker2('bad_stack3.py')
    Wrong open parenthesis at line 12, char number 34, the problem is >>> A module for stack data structure [.
    """
    par_open = {'(':[], '[':[], '{':[]}
    par_close = {')':'(', ']':'[', '}':'{'}
    
    f=open(filename, mode="r", encoding="utf-8")
    for i_line, line in enumerate(f, start=1):
        for i_char, char in enumerate(line, start=1):
            if char in par_open:
                par_open[char].append(Parenthesis(i_line=i_line, line=line, i_char=i_char))
            elif char in par_close:
                try:
                    par_open[par_close[char]].pop()
                except IndexError:
                    print(ParenthesisError(Parenthesis(i_line=i_line, line=line, i_char=i_char), 'Wrong closed parenthesis '))
    
    for _, l in par_open.items():
        for parenthesis in l:
            print(ParenthesisError(parenthesis, 'Wrong open parenthesis'))


if __name__ == "__main__":
   import doctest, sys
   doctest.testmod()

   n = str(sys.argv[1])
   print(parentheses_checker2(n))
